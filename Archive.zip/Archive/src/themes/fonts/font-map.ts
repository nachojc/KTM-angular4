import { FontSource } from 'expo-font';

export const fontMap: Record<string, FontSource> = {
  'SourceSansPro-Bold': require('./assets/SourceSansPro/SourceSansPro-Bold.ttf'),
  'SourceSansPro-Regular': require('./assets/SourceSansPro/SourceSansPro-Regular.ttf'),
  'SourceSansPro-SemiBold': require('./assets/SourceSansPro/SourceSansPro-SemiBold.ttf'),
  'SourceSansPro-Italic': require('./assets/SourceSansPro/SourceSansPro-Italic.ttf'),
  'AvivaCurve-SemiBold': require('./assets/AvivaCurve/AvivaCurve-SemiBold.otf'),
  'AvivaCurve-Regular': require('./assets/AvivaCurve/AvivaCurve-Regular.otf'),
};
