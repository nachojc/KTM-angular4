// FontLoader.tsx
import { useCallback, ReactNode } from 'react';
import { View } from 'react-native';
import { useFonts } from 'expo-font';

type Props = {
  children: ReactNode;
  onFontsLoaded?: () => void; // callback for displaying the splash screen once background view has loaded
};

export const FontLoader = ({ onFontsLoaded, children }: Props) => {
  const [fontsLoaded, error] = useFonts({
    'SourceSansPro-Bold': require('./assets/SourceSansPro/SourceSansPro-Bold.ttf'),
    'SourceSansPro-Regular': require('./assets/SourceSansPro/SourceSansPro-Regular.ttf'),
    'SourceSansPro-SemiBold': require('./assets/SourceSansPro/SourceSansPro-SemiBold.ttf'),
    'SourceSansPro-Italic': require('./assets/SourceSansPro/SourceSansPro-Italic.ttf'),
    'AvivaCurve-SemiBold': require('./assets/AvivaCurve/AvivaCurve-SemiBold.otf'),
    'AvivaCurve-Regular': require('./assets/AvivaCurve/AvivaCurve-Regular.otf'),
  });

  const onLayoutRootView = useCallback(async () => {
    if (fontsLoaded) {
      onFontsLoaded?.();
    }
  }, [fontsLoaded, onFontsLoaded]);
  console.log({ fontsLoaded, error });

  if (!fontsLoaded) {
    return null;
  }
  return (
    <View
      onLayout={onLayoutRootView}
      style={{
        flex: 1,
        backgroundColor: 'transparent',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      {children}
    </View>
  );
};
