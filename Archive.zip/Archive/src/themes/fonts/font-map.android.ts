import { FontSource } from 'expo-font';

// rn-bridge-nuance bundles the fonts in Android's res/font folder.
// To avoid duplicating the fonts in the bundle, we don't import fonts for Android in JS.
// Instead, we add the custom fonts in MainActivity.java
// See patches/MainActivity.java.patch
export const fontMap: Record<string, FontSource> = {};
