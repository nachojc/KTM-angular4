import {
  AllProps,
  createTheme,
  PropValue,
  BackgroundColorShorthandProps as RestyleBackgroundColorShorthandProps,
  BorderProps as RestyleBorderProps,
  LayoutProps as RestyleLayoutProps,
  OpacityProps as RestyleOpacityProps,
  PositionProps as RestylePositionProps,
  SpacingShorthandProps as RestyleSpacingShorthandProps,
  VariantProps as RestyleVariantProps,
  VisibleProps as RestyleVisibleProps,
  createRestyleComponent as untypedCreateRestyleComponent,
  composeRestyleFunctions as untypedCreateRestyleFunctions,
  useResponsiveProp as untypedUseResponsiveProp,
  useTheme as untypedUseTheme,
} from '@shopify/restyle';
import { palette } from './palette';

export const fontFamily = {
  SourceSansProSemiBold: 'SourceSansPro-SemiBold',
  SourceSansProBold: 'SourceSansPro-Bold',
  SourceSansProRegular: 'SourceSansPro-Regular',
  SourceSansProItalic: 'SourceSansPro-Italic',
  AvivaCurveSemiBold: 'AvivaCurve-SemiBold',
  AvivaCurveRegular: 'AvivaCurve-Regular',
};

export const theme = createTheme({
  colors: {
    primary: palette.Yellow500,
    secondary: palette.Blue800,
    tertiary: palette.Blue600,
    white: palette.Neutral100,
    gray: palette.Neutral400,
    darkGray: palette.Neutral700,
    lightBlue: palette.Blue300,
    black: palette.Opacity100,
    textColorLight: palette.Neutral100,
    textColorDark: palette.Neutral900,
    iconDark: palette.Neutral900,
    iconLight: palette.Neutral100,
    iconDarkLink: palette.Blue600,
    iconLightLink: palette.Yellow500,
    iconDisabled: palette.Neutral400,
    modalBackground: palette.Neutral100,
    modalBackgroundOverlay: palette.Neutral900Opacity50,
  },
  /**
   * @description spacing can be used for the design of elements like space, radius, padding and margin.
   */
  spacing: {
    0: 0,
    '6xs': 1,
    '5xs': 2,
    '4xs': 4,
    '3xs': 8,
    '2xs': 10,
    xs: 12,
    sm: 16,
    md: 24,
    lg: 32,
    xl: 40,
    '2xl': 48,
    '3xl': 56,
    '4xl': 64,
    '5xl': 72,
    '6xl': 80,
  },
  opacity: {},
  /**
   * @description layout can be used for width, height, etc.
   */
  layout: {
    height: {
      s: 44,
      m: 56,
    },
  },
  borderRadii: {
    // TODO: use correct radius tokens
    md: 24,
    999: 999,
  },
  breakpoints: {
    sm: 360,
    md: 720,
    lg: 1080,
    xl: 1312,
  },
  textVariants: {
    //  Repetition of fontFamily for each textVariant is needed for showing variants while selecting it in Storybook.
    //  Putting fontFamily.SourceSansProRegular as the default value in props will lead to incorrect rendering variants in Storybook, as props have higher priority than textVariants.
    //  There is a way to set the default fontFamily for all variants by adding it to textVariants.default (object above),
    //  but doesn't work now and opened issue exist in Restyle repo  https://github.com/Shopify/restyle/issues/157.
    //  Once this issue is fixed, the fontFamily.SourceSansProRegular can me moved to default object.

    // common
    body: {
      fontFamily: fontFamily.SourceSansProRegular,
      fontSize: 16,
      lineHeight: 24,
    },
    bodySm: {
      fontFamily: fontFamily.SourceSansProRegular,
      fontSize: 14,
      lineHeight: 20,
    },
    caption: {
      fontFamily: fontFamily.SourceSansProItalic,
      fontSize: 16,
      lineHeight: 24,
    },
    tagline: {
      fontFamily: fontFamily.SourceSansProSemiBold,
      fontSize: 14,
      lineHeight: 20,
      letterSpacing: 1,
      textTransform: 'uppercase',
    },

    // mobile
    displayXlrgMobile: {
      fontFamily: fontFamily.AvivaCurveRegular,
      fontSize: 48,
      lineHeight: 56,
      letterSpacing: -0.2,
    },
    displayLrgMobile: {
      fontFamily: fontFamily.AvivaCurveRegular,
      fontSize: 40,
      lineHeight: 48,
      letterSpacing: -0.2,
    },
    displayMedMobile: {
      fontFamily: fontFamily.AvivaCurveRegular,
      fontSize: 32,
      lineHeight: 40,
      letterSpacing: -0.1,
    },
    displaySmlMobile: {
      fontFamily: fontFamily.AvivaCurveRegular,
      fontSize: 24,
      lineHeight: 32,
    },
    heading01Mobile: {
      fontFamily: fontFamily.SourceSansProRegular,
      fontSize: 32,
      lineHeight: 40,
      letterSpacing: -0.1,
    },
    heading02Mobile: {
      fontFamily: fontFamily.SourceSansProRegular,
      fontSize: 24,
      lineHeight: 32,
      letterSpacing: -0.1,
    },
    heading03Mobile: {
      fontFamily: fontFamily.SourceSansProRegular,
      fontSize: 20,
      lineHeight: 28,
    },
    heading04Mobile: {
      fontFamily: fontFamily.SourceSansProRegular,
      fontSize: 18,
      lineHeight: 24,
    },

    // tablet
    displayXlrgTablet: {
      fontFamily: fontFamily.AvivaCurveRegular,
      fontSize: 52,
      lineHeight: 60,
      letterSpacing: -0.2,
    },
    displayLrgTablet: {
      fontFamily: fontFamily.AvivaCurveRegular,
      fontSize: 44,
      lineHeight: 52,
      letterSpacing: -0.2,
    },
    displayMedTablet: {
      fontFamily: fontFamily.AvivaCurveRegular,
      fontSize: 36,
      lineHeight: 44,
      letterSpacing: -0.1,
    },
    displaySmlTablet: {
      fontFamily: fontFamily.AvivaCurveRegular,
      fontSize: 28,
      lineHeight: 36,
    },
    heading01Tablet: {
      fontFamily: fontFamily.SourceSansProRegular,
      fontSize: 36,
      lineHeight: 44,
      letterSpacing: -0.1,
    },
    heading02Tablet: {
      fontFamily: fontFamily.SourceSansProRegular,
      fontSize: 28,
      lineHeight: 36,
      letterSpacing: -0.1,
    },
    heading03Tablet: {
      fontFamily: fontFamily.SourceSansProRegular,
      fontSize: 24,
      lineHeight: 32,
    },
    heading04Tablet: {
      fontFamily: fontFamily.SourceSansProRegular,
      fontSize: 20,
      lineHeight: 28,
    },

    // desktop
    displayXlrgDesktop: {
      fontFamily: fontFamily.AvivaCurveRegular,
      fontSize: 56,
      lineHeight: 64,
      letterSpacing: -0.2,
    },
    displayLrgDesktop: {
      fontFamily: fontFamily.AvivaCurveRegular,
      fontSize: 48,
      lineHeight: 56,
      letterSpacing: -0.2,
    },
    displayMedDesktop: {
      fontFamily: fontFamily.AvivaCurveRegular,
      fontSize: 40,
      lineHeight: 48,
      letterSpacing: -0.1,
    },
    displaySmlDesktop: {
      fontFamily: fontFamily.AvivaCurveRegular,
      fontSize: 32,
      lineHeight: 40,
    },
    heading01Desktop: {
      fontFamily: fontFamily.SourceSansProRegular,
      fontSize: 40,
      lineHeight: 48,
      letterSpacing: -0.1,
    },
    heading02Desktop: {
      fontFamily: fontFamily.SourceSansProRegular,
      fontSize: 32,
      lineHeight: 40,
      letterSpacing: -0.1,
    },
    heading03Desktop: {
      fontFamily: fontFamily.SourceSansProRegular,
      fontSize: 28,
      lineHeight: 36,
    },
    heading04Desktop: {
      fontFamily: fontFamily.SourceSansProRegular,
      fontSize: 20,
      lineHeight: 28,
    },
  },
  buttonVariants: {
    defaults: {
      justifyContent: 'center',
      alignItems: 'center',
      borderRadius: 999,
      color: 'secondary',
      flexDirection: 'row',
      gap: '3xs',
    },
    primary: {
      backgroundColor: 'primary',
      color: 'secondary',
    },
    secondary: {
      borderColor: 'secondary',
      borderWidth: 1,
      color: 'secondary',
    },
    tertiary: {
      borderWidth: 0,
      borderRadius: 0,
      color: 'tertiary',
      gap: '4xs',
    },
    primaryDisabled: {
      backgroundColor: 'gray',
      color: 'darkGray',
    },
    secondaryDisabled: {
      borderWidth: 1,
      borderColor: 'gray',
      color: 'darkGray',
    },
    tertiaryDisabled: {
      color: 'gray',
      gap: '4xs',
    },
    primaryPressed: {
      backgroundColor: 'secondary',
      color: 'white',
    },
    secondaryPressed: {
      backgroundColor: 'secondary',
      color: 'white',
    },
    tertiaryPressed: {
      color: 'tertiary',
      gap: '4xs',
    },
  },
  buttonSizeVariants: {
    defaults: {
      minWidth: 140,
      maxWidth: 328,
      paddingHorizontal: 'lg',
      paddingVertical: 'sm',
      minHeight: 56,
    },
    regular: {
      minWidth: 140,
      maxWidth: 328,
      paddingHorizontal: 'lg',
      paddingVertical: 'sm',
      minHeight: 56,
    },
    small: {
      minWidth: 120,
      maxWidth: 328,
      paddingHorizontal: 'md',
      paddingVertical: 'xs',
      minHeight: 48,
    },
    tertiary: {
      paddingHorizontal: 0,
      minHeight: 48,
      minWidth: 48,
      paddingVertical: 'sm',
    },
  },
  iconVariants: {
    '16': 16,
    '24': 24,
    '40': 40,
  },
  shadowVariants: {
    md: {
      elevation: 6,
      shadowColor: 'black',
      shadowRadius: 16,
      shadowOpacity: 0.1,
    },
  },
});

export type Theme = typeof theme;

export const useTheme = untypedUseTheme<Theme>;

export const useResponsiveProp = <T extends PropValue>(
  ...args: Parameters<typeof untypedUseResponsiveProp<Theme, T>>
) => untypedUseResponsiveProp(...args);

export const createRestyleComponent = <T extends { [key: string]: any }>(
  ...args: Parameters<typeof untypedCreateRestyleComponent<T, Theme>>
) => untypedCreateRestyleComponent(...args);

export const createRestyleFunctions = <T extends AllProps<Theme>>(
  ...args: Parameters<typeof untypedCreateRestyleFunctions<Theme, T>>
) => untypedCreateRestyleFunctions(...args);

export type BackgroundColorShorthandProps =
  RestyleBackgroundColorShorthandProps<Theme>;
export type OpacityProps = RestyleOpacityProps<Theme>;
export type VisibleProps = RestyleVisibleProps<Theme>;
export type LayoutProps = RestyleLayoutProps<Theme>;
export type SpacingShorthandProps = RestyleSpacingShorthandProps<Theme>;
export type BorderProps = RestyleBorderProps<Theme>;
export type PositionProps = RestylePositionProps<Theme>;
export type VariantProps<
  ThemeKey extends keyof Theme,
  Property extends string = 'variant'
> = RestyleVariantProps<Theme, ThemeKey, Property>;
