/**
 * Export SVG files as individual icons to be consumed by Icon component via the 'name' prop.
 * To derive icons from existing file via props (e.g. colour variant) export such icons as
 * tuples with name as the first element and icons props as the second element of the tuple.
 */
import { FC } from 'react';
import { SvgProps } from 'react-native-svg';

import add from './add.svg';
import addCircle from './add_circle.svg';
import alertCircle from './alert_circle.svg';
import archive from './archive.svg';
import arrowCircleDown from './arrow_circle_down.svg';
import arrowLeft from './arrow_left.svg';
import arrowRight from './arrow_right.svg';
import arrowUp from './arrow_up.svg';
import attachment from './attachment.svg';
import award from './award.svg';
import backToTop from './back_to_top.svg';
import barChart from './bar_chart.svg';
import bell from './bell.svg';
import bellOff from './bell_off.svg';
import book from './book.svg';
import bookOpen from './book_open.svg';
import bookmark from './bookmark.svg';
import calculate from './calculate.svg';
import calendar from './calendar.svg';
import camera from './camera.svg';
import cameraOff from './camera_off.svg';
import chatBubble from './chat_bubble.svg';
import chatSms from './chat_sms.svg';
import check from './check.svg';
import checkCircle from './check_circle.svg';
import circleOff from './circle_off.svg';
import circleOn from './circle_on.svg';
import clipboard from './clipboard.svg';
import clock from './clock.svg';
import close from './close.svg';
import closeCircle from './close_circle.svg';
import closeSmall from './close_small.svg';
import coffee from './coffee.svg';
import contentCopy from './content_copy.svg';
import counter1 from './counter_1.svg';
import counter2 from './counter_2.svg';
import counter3 from './counter_3.svg';
import counter4 from './counter_4.svg';
import counter5 from './counter_5.svg';
import creditCard from './credit_card.svg';
import deleteIcon from './delete.svg';
import desktop from './desktop.svg';
import download from './download.svg';
import edit from './edit.svg';
import email from './email.svg';
import externalLink from './external_link.svg';
import favouriteOff from './favourite_off.svg';
import favouriteOn from './favourite_on.svg';
import file from './file.svg';
import fileText from './file_text.svg';
import grid from './grid.svg';
import helpCircle from './help_circle.svg';
import home from './home.svg';
import info from './info.svg';
import iosShare from './ios_share.svg';
import language from './language.svg';
import laptop from './laptop.svg';
import link from './link.svg';
import list from './list.svg';
import lockOpen from './lock-open.svg';
import lock from './lock.svg';
import login from './login.svg';
import logout from './logout.svg';
import map from './map.svg';
import mapPin from './map_pin.svg';
import medical from './medical.svg';
import menu from './menu.svg';
import monitoring from './monitoring.svg';
import moreHorz from './more_horz.svg';
import moreVert from './more_vert.svg';
import myLocation from './my_location.svg';
import newWindow from './new_window.svg';
import pause from './pause.svg';
import phone from './phone.svg';
import phoneCall from './phone_call.svg';
import phoneIncoming from './phone_incoming.svg';
import pieChart from './pie_chart.svg';
import playArrow from './play_arrow.svg';
import playCircle from './play_circle.svg';
import print from './print.svg';
import progressActivity from './progress_activity.svg';
import puzzle from './puzzle.svg';
import refresh from './refresh.svg';
import remove from './remove.svg';
import removeCircle from './remove_circle.svg';
import reply from './reply.svg';
import rssFeed from './rss_feed.svg';
import save from './save.svg';
import search from './search.svg';
import send from './send.svg';
import settings from './settings.svg';
import share from './share.svg';
import shopping from './shopping.svg';
import shoppingCart from './shopping_cart.svg';
import sliders from './sliders.svg';
import smartphone from './smartphone.svg';
import star from './star.svg';
import sync from './sync.svg';
import tablet from './tablet.svg';
import tag from './tag.svg';
import thumbDown from './thumb_down.svg';
import thumbUp from './thumb_up.svg';
import timer from './timer.svg';
import trendingDown from './trending_down.svg';
import trendingUp from './trending_up.svg';
import upload from './upload.svg';
import user from './user.svg';
import users from './users.svg';
import visibility from './visibility.svg';
import visibilityOff from './visibility_off.svg';

/**
 * Export all icons here. Icons can be composed from SVGs with props of the Icon
 * component (i.e. SVG) predefined, which makes it easy to create icon variations
 * (dark and light, or rotate them with style prop (e.g. `style: { transform: [{ rotate: '90deg' }] }`)).
 */
export const icons = {
  add,
  'add-circle': addCircle,
  'alert-circle': alertCircle,
  archive,
  'arrow-circle_down': arrowCircleDown,
  'arrow-down': [arrowUp, { style: { transform: [{ rotateX: '180deg' }] } }],
  'arrow-left': arrowLeft,
  'arrow-right': arrowRight,
  'arrow-up': arrowUp,
  attachment,
  award,
  'back-to_top': backToTop,
  'bar-chart': barChart,
  bell,
  'bell-off': bellOff,
  book,
  'book-open': bookOpen,
  bookmark,
  calculate,
  calendar,
  camera,
  'camera-off': cameraOff,
  'chat-bubble': chatBubble,
  'chat-sms': chatSms,
  check,
  'check-circle': checkCircle,
  'circle-off': circleOff,
  'circle-on': circleOn,
  clipboard,
  clock,
  close,
  'close-circle': closeCircle,
  'close-small': closeSmall,
  coffee,
  'content-copy': contentCopy,
  'counter-1': counter1,
  'counter-2': counter2,
  'counter-3': counter3,
  'counter-4': counter4,
  'counter-5': counter5,
  'credit-card': creditCard,
  delete: deleteIcon,
  desktop,
  download,
  edit,
  email,
  'external-link': externalLink,
  'favourite-off': favouriteOff,
  'favourite-on': favouriteOn,
  file,
  'file-text': fileText,
  grid,
  'help-circle': helpCircle,
  home,
  info,
  'ios-share': iosShare,
  language,
  laptop,
  link,
  list,
  lock,
  'lock-open': lockOpen,
  login,
  logout,
  map,
  'map-pin': mapPin,
  medical,
  menu,
  monitoring,
  'more-horz': moreHorz,
  'more-vert': moreVert,
  'my-location': myLocation,
  'new-window': newWindow,
  pause,
  phone,
  'phone-call': phoneCall,
  'phone-incoming': phoneIncoming,
  'pie-chart': pieChart,
  'play-arrow': playArrow,
  'play-circle': playCircle,
  print,
  'progress-activity': progressActivity,
  puzzle,
  refresh,
  remove,
  'remove-circle': removeCircle,
  reply,
  'rss-feed': rssFeed,
  save,
  search,
  send,
  settings,
  share,
  shopping,
  'shopping-cart': shoppingCart,
  sliders,
  smartphone,
  star,
  sync,
  tablet,
  tag,
  'thumb-down': thumbDown,
  'thumb-up': thumbUp,
  timer,
  'trending-down': trendingDown,
  'trending-up': trendingUp,
  upload,
  user,
  users,
  visibility,
  'visibility-off': visibilityOff,
} satisfies Record<string, FC<SvgProps> | [FC<SvgProps>, SvgProps]>;
