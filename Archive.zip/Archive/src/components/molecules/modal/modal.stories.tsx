import { useArgs } from '@storybook/preview-api';
import { Meta, StoryObj } from '@storybook/react';
import {
  SafeAreaInsetsContext,
  SafeAreaProvider,
} from 'react-native-safe-area-context';
import { getRandomWords } from '../../../utils/get-random-words';
import { Box } from '../../atoms/box';
import { Button } from '../../atoms/button';
import { Text } from '../../atoms/text';
import { Modal } from './modal';

/** The `Modal` component is a custom modal component built using [React Native Modal](https://reactnative.dev/docs/modal) and [Shopify/Restyle library](https://shopify.github.io/restyle/fundamentals).
 */

/**  ## Design & Behavior
 *   <p> **Modal overlay color**: Modals by default always displayed with overlay using "modalBackgroundOverlay" color. </p>
 *   <p> **Modal background color**:  by default it is "modalBackground".</p>
 *   <p> **Border-radius**: on breakpoints Mobile("sm") and Tablet("md") border-radius is "md" top left and top right mobile and on Tablet("lg") and Tablet landscape("xl") border-radius "md" on all corners. </p>
 *   <p> **Appearance**: on breakpoints Tablet("lg") and Tablet landscape("xl") the modal appears in the centre of the viewport. On breakpoints Mobile("sm") and Tablet("md") modal has full width and height can be displayed at either min 50% to 100% of the viewport height, depending on the information being displayed to the user from the of bottom screen.</p>
 *   <p> **SafeAreaProvider**: Modal uses `useSafeAreaInsets` hook from [react-native-safe-area-context](https://docs.expo.dev/versions/latest/sdk/safe-area-context/) to get the direct access to the safe area insets. Make sure that you have SafeAreaProvider in your app root component.</p>
 */

const meta: Meta<typeof Modal> = {
  component: Modal,
  title: 'Molecules/Modal',
  tags: ['autodocs'],
  args: { visible: false },
  argTypes: {
    visible: {
      control: 'boolean',
      description: 'Controls the visibility of the modal',
    },
    onClose: {
      description:
        'Callback function called when the modal is requested to be closed',
    },
    closeButtonLabel: {
      description: `closeButtonLabel should always be 'Close' (or its local language equivalent)`,
    },
    closeButtonAccessibilityLabel: {
      description: `closeButtonAccessibilityLabel should be 'Close Modal' (or its local language equivalent) `,
    },
  },
  decorators: [
    (Story) => {
      // SafeAreaProvider allow useSafeAreaInsets get the current safe area insets.
      // Should be placed inside of the Modal story, not in the preview.tsx to make sure that component have the correct view of hierarchy to get the insets and do not conflict with Storybook context and safe area.
      // In the app (e.g. MANGA ) the Modal will get the insets from SafeAreaProvider which is based in the app root component.
      const insets = { top: 50, bottom: 0, left: 0, right: 0 };

      return (
        <SafeAreaProvider>
          <SafeAreaInsetsContext.Provider value={insets}>
            {Story()}
          </SafeAreaInsetsContext.Provider>
        </SafeAreaProvider>
      );
    },
  ],
};

type Story = StoryObj<typeof Modal>;

export default meta;

export const ModalWithScrollView: Story = {
  args: { visible: false },
  render: function Render(args) {
    const [{ visible }, updateArgs] = useArgs();

    const onPress = () => updateArgs({ visible: !visible });

    return (
      <Box flex={1} justifyContent="center" alignItems="center">
        <Button variant="primary" onPress={onPress}>
          <Button.Text>Show Modal</Button.Text>
        </Button>
        <Modal
          {...args}
          onClose={onPress}
          closeButtonLabel="Close"
          closeButtonAccessibilityLabel="Close modal"
        >
          <Text variant="heading01Tablet" accessibilityRole="header" mb="md">
            Header of Modal
          </Text>

          <Box g="md">
            <Text>{getRandomWords(35)}</Text>
            <Text>{getRandomWords(35)}</Text>
            <Text>{getRandomWords(105)}</Text>
            <Text>{getRandomWords(86)}</Text>
            <Text>{getRandomWords(86)}</Text>
            <Text>{getRandomWords(86)}</Text>
            <Text>{getRandomWords(86)}</Text>
            <Text>{getRandomWords(86)}</Text>
          </Box>
        </Modal>
      </Box>
    );
  },
};

export const ModalWithoutCloseButton: Story = {
  args: { visible: false },
  render: function Render({
    onClose,
    closeButtonLabel,
    closeButtonAccessibilityLabel,
    ...rest
  }) {
    const [{ visible }, updateArgs] = useArgs();

    const onPress = () => updateArgs({ visible: !visible });

    return (
      <Box flex={1} justifyContent="center" alignItems="center">
        <Button variant="primary" onPress={onPress}>
          <Button.Text>Show Modal</Button.Text>
        </Button>
        <Modal {...rest}>
          <Text variant="heading01Tablet" accessibilityRole="header" mb="md">
            Header of Modal
          </Text>

          <Box g="md">
            <Text>{getRandomWords(40)}</Text>
            <Text>{getRandomWords(5)}</Text>
            <Text>{getRandomWords(35)}</Text>
            <Button variant="tertiary" alignSelf="flex-start" onPress={onPress}>
              <Button.Text>Close Modal</Button.Text>
            </Button>
          </Box>
        </Modal>
      </Box>
    );
  },
};

export const ModalWithoutScrollView: Story = {
  args: { visible: false },
  render: function Render(args) {
    const [{ visible }, updateArgs] = useArgs();

    const onPress = () => updateArgs({ visible: !visible });

    return (
      <Box flex={1} justifyContent="center" alignItems="center">
        <Button variant="primary" onPress={onPress}>
          <Button.Text>Show Modal</Button.Text>
        </Button>
        <Modal
          {...args}
          onClose={onPress}
          closeButtonLabel="Close"
          closeButtonAccessibilityLabel="Close modal"
        >
          <Text variant="heading01Tablet" accessibilityRole="header" mb="md">
            Header of Modal
          </Text>

          <Box g="md">
            <Text>{getRandomWords(40)}</Text>
            <Text>{getRandomWords(5)}</Text>
            <Text>{getRandomWords(35)}</Text>
          </Box>
        </Modal>
      </Box>
    );
  },
};
