import { render, screen } from '../../../../../jest/testing-library';
import { Text } from '../../../atoms/text/text';
import { Modal } from '../modal';

describe('Modal', () => {
  it('renders with close button', () => {
    render(
      <Modal
        onClose={jest.fn()}
        visible
        closeButtonLabel="Close"
        closeButtonAccessibilityLabel="Close modal"
      >
        <Text>Modal content</Text>
      </Modal>
    );

    expect(screen).toMatchSnapshot();
  });

  it('renders without close button', () => {
    render(
      <Modal visible>
        <Text>Modal content</Text>
      </Modal>
    );

    expect(screen).toMatchSnapshot();
  });

  it('renders correctly when not visible', () => {
    render(
      <Modal visible={false}>
        <Text>Modal content</Text>
      </Modal>
    );

    expect(screen).toMatchSnapshot();
  });
});
