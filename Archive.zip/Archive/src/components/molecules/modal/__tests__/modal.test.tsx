import { fireEvent, render, screen } from '../../../../../jest/testing-library';
import { Text } from '../../../atoms/text';
import { Modal } from '../modal';

describe('Modal Component', () => {
  it('is visible when the visible prop is true', () => {
    render(
      <Modal visible>
        <Text>Modal</Text>
      </Modal>
    );

    expect(screen.getByText('Modal')).toBeVisible();
  });

  it('should display close button when onClose is passed', () => {
    const mockOnPress = jest.fn();
    render(
      <Modal
        visible
        onClose={mockOnPress}
        closeButtonLabel="Close"
        closeButtonAccessibilityLabel="Close modal"
      />
    );

    expect(screen.getByText('Close')).toBeOnTheScreen();
  });

  it('closes when the close button is pressed', () => {
    const mockOnPress = jest.fn();
    render(
      <Modal
        onClose={mockOnPress}
        visible
        closeButtonLabel="Close"
        closeButtonAccessibilityLabel="Close modal"
      />
    );

    const modalCloseButton = screen.getByText('Close');
    fireEvent.press(modalCloseButton);

    expect(mockOnPress).toHaveBeenCalled();
  });

  it('should close  when pressing outside of modal', () => {
    const mockOnPress = jest.fn();
    render(
      <Modal
        onClose={mockOnPress}
        visible
        closeButtonLabel="Close"
        closeButtonAccessibilityLabel="Close modal"
      />
    );

    const modalBackdrop = screen.getByTestId('modal-backdrop');
    fireEvent.press(modalBackdrop);

    expect(mockOnPress).toHaveBeenCalled();
  });

  it('should display the correct content', () => {
    render(
      <Modal visible>
        <Text variant="heading01Tablet" accessibilityRole="header" mb="md">
          Header of Modal
        </Text>
        <Text>Content of Modal</Text>
      </Modal>
    );

    const header = screen.getByText('Header of Modal');
    const content = screen.getByText('Content of Modal');

    expect(header).toBeOnTheScreen();
    expect(content).toBeOnTheScreen();
  });
});
