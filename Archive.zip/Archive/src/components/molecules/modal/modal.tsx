import {
  Modal as RNModal,
  ModalProps as RNModalProps,
  ScrollView,
  StyleSheet,
} from 'react-native';
import Animated, {
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from 'react-native-reanimated';

import { useEffect, useState } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useResponsiveProp, useTheme } from '../../../themes/theme';
import { Box } from '../../atoms/box';
import { Button } from '../../atoms/button';
import { Pressable } from '../../atoms/pressable';

type ModalWithCloseProps = {
  onClose: () => void;
  closeButtonLabel: string;
  closeButtonAccessibilityLabel: string;
};
type ModalWithoutCloseProps = {
  onClose?: never;
  closeButtonLabel?: never;
  closeButtonAccessibilityLabel?: never;
};
export type ModalProps = Pick<
  RNModalProps,
  'onShow' | 'onRequestClose' | 'children'
> & {
  visible: boolean;
} & (ModalWithCloseProps | ModalWithoutCloseProps);

const AnimatedBox = Animated.createAnimatedComponent(Box);

export const Modal = ({
  onClose,
  closeButtonLabel,
  closeButtonAccessibilityLabel,
  children,
  visible: isVisible,
  ...rest
}: ModalProps) => {
  const { md, lg } = useTheme().spacing;
  const paddingHorizontal = useResponsiveProp<number>({ sm: md, md: lg, lg });
  const animationType = useResponsiveProp<RNModalProps['animationType']>({
    sm: 'slide',
    md: 'slide',
    lg: 'fade',
  });

  const insets = useSafeAreaInsets();

  const [visible, setVisible] = useState(isVisible);
  const modalHeight = useSharedValue(0);
  const progress = useSharedValue(0);

  useEffect(() => {
    if (isVisible) {
      setVisible(true);
      progress.value = withTiming(0, { duration: 500 });
    } else {
      progress.value = withTiming(1, { duration: 500 }, (isFinished) => {
        if (isFinished) {
          runOnJS(setVisible)(false);
        }
      });
    }
  }, [isVisible, progress]);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: progress.value * modalHeight.value }],
  }));

  return (
    <RNModal animationType="fade" visible={visible} {...rest}>
      <Box
        flex={1}
        justifyContent={{ sm: 'flex-end', md: 'flex-end', lg: 'center' }}
        alignItems={{ lg: 'center', xl: 'center' }}
        style={{ paddingTop: insets.top }}
      >
        <Pressable
          accessible={false}
          bg="modalBackgroundOverlay"
          testID="modal-backdrop"
          onPress={onClose}
          style={StyleSheet.absoluteFill}
        />
        <AnimatedBox
          onLayout={(e) => (modalHeight.value = e.nativeEvent.layout.height)}
          style={animationType === 'slide' && animatedStyle}
          bg="modalBackground"
          pt={onClose ? 0 : 'lg'}
          pb={{ sm: 'sm', md: 'lg', lg: 'lg' }}
          maxHeight={{ sm: '100%', md: '100%', lg: '80%' }}
          maxWidth={{ lg: '66%' }}
          minHeight={{ sm: '50%', md: 0 }}
          borderTopRightRadius="md"
          borderTopLeftRadius="md"
          borderBottomRightRadius={{ lg: 'md' }}
          borderBottomLeftRadius={{ lg: 'md' }}
        >
          {onClose && (
            <Button
              mr={{ sm: 'md', md: 'md', lg: 'lg' }}
              variant="tertiary"
              accessibilityLabel={closeButtonAccessibilityLabel}
              alignSelf="flex-end"
              onPress={onClose}
            >
              <Button.Text>{closeButtonLabel}</Button.Text>
              <Button.Icon name="close" />
            </Button>
          )}
          <ScrollView
            alwaysBounceVertical={false}
            style={{ paddingHorizontal, flexGrow: 0 }}
          >
            {children}
          </ScrollView>
        </AnimatedBox>
      </Box>
    </RNModal>
  );
};

Modal.displayName = 'Modal';
