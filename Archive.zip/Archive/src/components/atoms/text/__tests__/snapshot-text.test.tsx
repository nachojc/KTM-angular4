import { render, screen } from '../../../../../jest/testing-library';
import { Text } from '../text';

describe('Text Component', () => {
  it('renders Text with default values correctly', () => {
    render(<Text />).toJSON();
    expect(screen).toMatchSnapshot();
  });
});
