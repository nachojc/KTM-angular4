import { render, screen } from '../../../../../jest/testing-library';
import { Text } from '../text';

describe('Text Component', () => {
  it('renders correctly with defaults', () => {
    render(<Text>Text Variant</Text>);

    const textElement = screen.getByText('Text Variant');

    expect(textElement).toBeTruthy();
    expect(textElement).toHaveStyle({
      fontFamily: 'SourceSansPro-Regular',
      fontSize: 16,
      lineHeight: 24,
      color: '#191919',
    });
    expect(textElement.props.accessibilityRole).toBe('text');
  });

  it('renders correctly on variant change', () => {
    render(<Text variant="tagline">Text Variant</Text>);

    const textElement = screen.getByText('Text Variant');

    expect(textElement).toBeTruthy();
    expect(textElement).toHaveStyle({
      fontFamily: 'SourceSansPro-SemiBold',
      fontSize: 14,
      lineHeight: 20,
      letterSpacing: 1,
      textTransform: 'uppercase',
      color: '#191919',
    });
  });

  it('should accept custom props', () => {
    render(
      <Text
        variant="heading01Mobile"
        accessibilityRole="header"
        color="primary"
        testID="testID"
        textDecorationLine="line-through"
        fontFamily="SourceSansPro-SemiBold"
      >
        Custom Text Variant
      </Text>
    );

    const textElement = screen.getByText('Custom Text Variant');

    expect(textElement).toBeTruthy();
    expect(textElement).toHaveStyle({
      fontFamily: 'SourceSansPro-SemiBold',
      fontSize: 32,
      lineHeight: 40,
      letterSpacing: -0.1,
      color: '#FFD900',
      textDecorationLine: 'line-through',
    });
    expect(textElement.props.accessibilityRole).toBe('header');
    expect(textElement.props.testID).toBe('testID');
  });

  it('should accept accessability attributes', () => {
    render(
      <Text
        accessibilityHint="Hint for the text"
        accessibilityElementsHidden={false}
        importantForAccessibility="yes"
        accessibilityRole="header"
        accessibilityLabel="custom label"
      >
        Accessible Text Variant
      </Text>
    );

    const textElement = screen.getByLabelText('custom label');
    expect(textElement).toBeTruthy();
    expect(textElement.props.accessibilityHint).toBe('Hint for the text');
    expect(textElement.props.accessibilityElementsHidden).toBeFalsy();
    expect(textElement.props.importantForAccessibility).toBe('yes');
    expect(textElement.props.accessibilityRole).toBe('header');
  });
});
