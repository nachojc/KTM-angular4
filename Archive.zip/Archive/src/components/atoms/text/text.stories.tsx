import { Meta } from '@storybook/react';
import { fontFamily, theme } from '../../../themes/theme';
import { Text, TextProps } from './text';

type StorybookTextProps = TextProps & { text: string };

/** The `Text` component is a custom text component built using [Shopify/Restyle library](https://shopify.github.io/restyle/fundamentals/components/predefined-components).
 * <p>It extends the functionality of the React Native `Text` component by adding additional styling properties for better design control.</p>
 */

/**
 * ## Usage
 * The `Text` component inherits all properties from the React Native `Text` component, except `style`. Styling should be done by passing style properties directly as props.
 */

const TextMeta: Meta<StorybookTextProps> = {
  component: (args) => <Text {...args}>{args.text}</Text>,
  title: 'Atoms/Text',
  tags: ['autodocs'],
  args: {
    text: 'Text variant',
    variant: 'body',
    accessibilityRole: 'text',
    testID: 'testId',
    color: 'textColorDark',
    fontFamily: 'SourceSansPro-Regular',
  },
  argTypes: {
    variant: {
      options: Object.keys(theme.textVariants).filter(
        (key) => key !== 'default'
      ),
      control: { type: 'select' },
      description: 'Variant allows to apply predefined styles from the theme.',
      table: {
        defaultValue: { summary: 'body' },
      },
    },
    fontFamily: {
      options: Object.values(fontFamily),
      control: { type: 'select' },
      description:
        'Specifies the font family for the text. This property can also be used to change the font weight by selecting a font family that corresponds to different weight (e.g. SourceSansProBold will refer to fontWeight: 700.',
    },
    color: {
      options: Object.keys(theme.colors),
      mapping: Object.values(theme.colors),
      control: { type: 'select' },
      description:
        'Color options from theme. It is recommended to use textColorLight on dark background and textColorDark on light background. Additionally, other color options can be used in accordance with the design requirements.',
      table: {
        defaultValue: { summary: 'textColorDark' },
      },
    },
    letterSpacing: {
      control: { type: 'number' },
      description: 'Adjusts the spacing between characters in the text.',
    },
    accessibilityRole: {
      control: { type: 'text' },
      description:
        'Accessibility role can be only those that is allowed by the React Native: https://reactnative.dev/docs/accessibility#accessibilityrole',
      table: {
        defaultValue: { summary: 'text' },
      },
    },
  },
};

export default TextMeta;

export const Default = (args: StorybookTextProps) => (
  <Text {...args}>{args.text}</Text>
);
