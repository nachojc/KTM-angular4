import { TextProps as RNTextProps } from 'react-native';
import {
  TextProps as RestyleTextProps,
  createText,
  LayoutProps,
} from '@shopify/restyle';
import { Theme } from '../../../themes/theme';

export type TextProps = RestyleTextProps<Theme> &
  LayoutProps<Theme> &
  Omit<RNTextProps, 'style'>;

/**
 * @description The 'Text' component is a versatile element for displaying text.
 * The 'Text' component supports the 'variant' props (e.g. 'body', 'heading01Mobile', etc.), which allows to apply predefined styles.
 * These variants are defined in the theme and can be customized by using the props.
 * The 'Text' component leverages the styling capabilities of Shopify/Restyle library https://shopify.github.io/restyle/fundamentals/restyle-functions.
 * This allows you to pass style directly to the component, e.g. you can pass style props such as 'color', 'textDecorationLine', 'fontFamily' directly to the component.
 * Also, 'Text' component inherit all props from React Native Text.
 */
export const Text = createText<Theme, TextProps>();

Text.defaultProps = {
  variant: 'body',
  accessibilityRole: 'text',
  color: 'textColorDark',
};

Text.displayName = 'Text';
