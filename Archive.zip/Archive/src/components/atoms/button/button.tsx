import {
  ColorProps,
  LayoutProps,
  SpacingProps,
  VariantProps,
  color,
  createRestyleComponent,
  createVariant,
  layout,
  spacing,
} from '@shopify/restyle';

import { Theme, useTheme } from '../../../themes/theme';
import { Pressable } from '../pressable';

import { Children, cloneElement, useState } from 'react';
import { ButtonIcon } from './button-icon';
import { ButtonText } from './button-text';

export type ButtonProps = RestyleProps &
  Omit<React.ComponentProps<typeof BaseButton>, 'variant'> & {
    variant?: Extract<
      keyof Theme['buttonVariants'],
      'primary' | 'secondary' | 'tertiary'
    >;
    disabled?: boolean;
    size?: Exclude<keyof Theme['buttonSizeVariants'], 'tertiary'>;
  };

export const Button = ({
  disabled,
  variant = 'primary',
  size,
  children,
  ...rest
}: ButtonProps) => {
  const { buttonVariants } = useTheme();
  const [pressed, setPressed] = useState(false);

  const variantDisabled = disabled ? (`${variant}Disabled` as const) : variant;
  const variantPressed = `${variant}Pressed` as const;

  const finalVariant = pressed ? variantPressed : variantDisabled;

  return (
    <BaseButton
      accessibilityRole="button"
      variant={finalVariant}
      disabled={disabled}
      size={variant === 'tertiary' ? 'tertiary' : size}
      onPressIn={(e) => {
        setPressed(true);
        rest.onPressIn?.(e);
      }}
      onPressOut={(e) => {
        setPressed(false);
        rest.onPressOut?.(e);
      }}
      {...rest}
    >
      {children &&
        Children.map(children, (child) =>
          cloneElement(child as React.ReactElement<any>, {
            color: buttonVariants[finalVariant].color,
            pressed,
            variant,
          })
        )}
    </BaseButton>
  );
};

type RestyleProps = LayoutProps<Theme> &
  ColorProps<Theme> &
  SpacingProps<Theme>;

const BaseButton = createRestyleComponent<
  VariantProps<Theme, 'buttonVariants'> &
    VariantProps<Theme, 'buttonSizeVariants', 'size'> &
    React.ComponentProps<typeof Pressable> &
    RestyleProps,
  Theme
>(
  [
    createVariant({ themeKey: 'buttonVariants' }),
    createVariant({ themeKey: 'buttonSizeVariants', property: 'size' }),
    spacing,
    layout,
    color,
  ],
  Pressable
);

Button.Icon = ButtonIcon;
Button.Text = ButtonText;
