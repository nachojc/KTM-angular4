import { Icon, IconProps } from '../icon/icon';

export type ButtonIconProps = Pick<IconProps, 'name' | 'color'>;

export const ButtonIcon = ({ name, color }: ButtonIconProps) => (
  <Icon name={name} color={color} />
);

ButtonIcon.displayName = 'Button.Icon';
