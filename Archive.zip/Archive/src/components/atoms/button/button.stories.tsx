import { Meta, StoryObj } from '@storybook/react';
import { Button, ButtonProps } from './button';
import { icons } from '../../../themes/icons';
import { IconName } from '../icon';

type StoryButtonArgs = ButtonProps & {
  text: string;
  iconLeft: IconName;
  iconRight: IconName;
};
/**
 * # Description
 * The 'Button' Component allows to create pressable buttons with 3 color schemes and 2 sizes <br>
 * Button allows every [Pressable](https://reactnative.dev/docs/pressable) and [Restyle spacing, layout, color](https://shopify.github.io/restyle/fundamentals/restyle-functions) prop plus `variant` and `size` <br>
 * Button is created using composition. <br>
 * Take name of the icon from Material Symbols
 *
 * # Usage
 */

const ButtonMeta: Meta<StoryButtonArgs> = {
  title: 'Atoms/Button',
  component: (args) => (
    <Button {...args}>
      <Button.Text>{args.text}</Button.Text>
    </Button>
  ),
  tags: ['autodocs'],
  args: {
    disabled: false,
    width: '100%',
    size: 'regular',
    variant: 'primary',
    text: 'Button',
  },
  parameters: { actions: { argTypesRegex: '^on.*' } },
  argTypes: {
    variant: {
      options: ['primary', 'secondary', 'tertiary'],
      control: { type: 'select' },
    },
    size: {
      options: ['small', 'regular'],
      control: { type: 'select' },
    },
    iconLeft: {
      options: [undefined, ...Object.keys(icons)],
      control: { type: 'select' },
    },
    iconRight: {
      options: [undefined, ...Object.keys(icons)],
      control: { type: 'select' },
    },
    onPress: { action: 'pressed', type: 'function' },
  },
};

export default ButtonMeta;

export const RegularButton = (args: StoryButtonArgs) => (
  <Button variant="primary" {...args}>
    <Button.Text>{args.text}</Button.Text>
  </Button>
);

export const ButtonWithIconLeft: StoryObj<StoryButtonArgs> = {
  args: {
    iconLeft: 'download',
  },
  render: (args: StoryButtonArgs) => (
    <Button variant="primary" {...args}>
      <Button.Icon name={args.iconLeft} />
      <Button.Text>{args.text}</Button.Text>
    </Button>
  ),
};

export const ButtonWithIconRight: StoryObj<StoryButtonArgs> = {
  args: {
    iconRight: 'download',
  },
  render: (args: StoryButtonArgs) => (
    <Button variant="primary" {...args}>
      <Button.Text>{args.text}</Button.Text>
      <Button.Icon name={args.iconRight} />
    </Button>
  ),
};

export const ButtonWithLongText: StoryObj<StoryButtonArgs> = {
  args: {
    text: 'Very Long Button Text Lorem Ipsum',
  },
  render: (args) => {
    return (
      <Button variant="primary" {...args}>
        <Button.Text>{args.text}</Button.Text>
        <Button.Icon name={args.iconRight ?? 'download'} />
      </Button>
    );
  },
};
