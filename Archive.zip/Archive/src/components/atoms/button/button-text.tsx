import { ResponsiveValue, VariantProps } from '@shopify/restyle';

import { PropsWithChildren } from 'react';
import { Theme } from '../../../themes/theme';
import { Box } from '../box';
import { Text } from '../text';

export type ButtonTextProps = PropsWithChildren<
  VariantProps<Theme, 'textVariants'> & {
    color?: keyof Theme['colors'];
    pressed?: boolean;
    variant?: Extract<
      ResponsiveValue<keyof Theme['buttonVariants'], Theme['breakpoints']>,
      'primary' | 'secondary' | 'tertiary'
    >;
  }
>;

export const ButtonText = ({
  children,
  color,
  pressed,
  variant,
}: ButtonTextProps) => {
  const decorationLine =
    variant === 'tertiary' && !pressed ? 'underline' : undefined;
  return (
    <Box flexShrink={1}>
      {/* to wrap text even without spaces edge case very unlike to happen */}
      <Text
        color={color}
        fontFamily="SourceSansPro-Bold"
        lineHeight={24}
        textDecorationLine={decorationLine}
        numberOfLines={2}
      >
        {children}
      </Text>
    </Box>
  );
};

ButtonText.displayName = 'Button.Text';
