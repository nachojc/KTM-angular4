import { render, screen } from '../../../../../jest';
import { Button } from '../button';

describe('Button', () => {
  it.each([
    ['primary', true],
    ['secondary', true],
    ['tertiary', true],
    ['primary', false],
    ['secondary', false],
    ['tertiary', false],
  ] as const)('should render %s button disabled = %s', (variant, disabled) => {
    render(
      <Button variant={variant} disabled={disabled}>
        <Button.Text>Press Me</Button.Text>
      </Button>
    );

    expect(screen).toMatchSnapshot();
  });
});
