import { fireEvent, render, screen } from '../../../../../jest';
import { theme } from '../../../../themes/theme';
import { Button } from '../button';

describe('Button', () => {
  it('should render button with default configuration', () => {
    render(
      <Button>
        <Button.Text>Press Me</Button.Text>
      </Button>
    );

    expect(screen.getByText('Press Me')).toBeVisible();
  });

  it('should call onPress function when tapped', () => {
    const mockOnPress = jest.fn();
    render(
      <Button onPress={mockOnPress} testID="btn">
        <Button.Text>Press Me</Button.Text>
      </Button>
    );

    const button = screen.getByText('Press Me');
    fireEvent.press(button);
    fireEvent.press(button);

    expect(mockOnPress).toHaveBeenCalledTimes(2);
  });

  it('renders correctly in disabled state', () => {
    render(
      <Button disabled testID="btn">
        <Button.Text>Press Me</Button.Text>
      </Button>
    );

    const button = screen.getByTestId('btn');
    const buttonText = screen.getByText('Press Me');

    expect(button).toHaveStyle({
      backgroundColor: theme.colors.gray,
    });
    expect(buttonText).toHaveStyle({
      color: theme.colors.darkGray,
    });
  });
});
