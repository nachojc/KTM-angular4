import { Meta } from '@storybook/react';
import { theme } from 'react-native-ion-mobile';
import { icons } from '../../../themes/icons';
import { Icon, IconProps } from './icon';

/**
 * Icon component which return an SVG icon.
 *
 * The icon can be styled inline with the help of `fill`, `stroke` and `color` props.
 * The `color` represents a general theme and corresponds to `currentColor` value in SVG.
 * This is usually the general color of the icon and can be applied to both stroke and fill.
 * For a more granular control use `fill` and `stroke` to style these attributes separately.
 * The icons generally set the default values for those attributes at the root of the SVG which
 * allows them to be overridden by this component.
 *
 * The `fill` and `stroke` props override the `color` prop.
 */

const IconMeta: Meta<IconProps> = {
  title: 'Atoms/Icon',
  component: Icon,
  tags: ['autodocs'],
  args: {
    color: 'iconDarkLink',
    name: 'add-circle',
    size: '24',
  },
  argTypes: {
    color: {
      options: Object.keys(theme.colors),
      mapping: Object.values(theme.colors),
      control: { type: 'select' },
      table: {
        defaultValue: { summary: 'iconDarkLink' },
      },
      description:
        'Color options from theme. It is recommended to use: **iconDark** on light background, **iconLight** on dark background, **iconDarkLink** for link icons on light background, **iconLightLink** link icons on dark background and **iconDisabled** for disabled icons on dark and light background.  ',
    },
    name: {
      options: Object.keys(icons),
      control: { type: 'select' },
      description: 'Name of icon',
    },
    size: {
      options: Object.keys(theme.iconVariants)
        .filter((key) => key !== 'defaults')
        .map((key) => Number(key)),
      control: { type: 'select' },
      table: {
        defaultValue: { summary: 24 },
      },
      description: 'Sets size for icon 16dp, 24dp (default) or 40dp',
    },
  },
};

export default IconMeta;

export const RegularIcon = {};
