import { FC } from 'react';
import { SvgProps } from 'react-native-svg';
import { icons } from '../../../themes/icons';
import { Theme, theme } from '../../../themes/theme';

export type IconName = keyof typeof icons;

export type IconProps = SvgProps & {
  name: IconName;
  color?: keyof Theme['colors'];
  size?: keyof Theme['iconVariants'];
};

export const Icon = ({
  name,
  width,
  height,
  color,
  accessibilityRole,
  accessibilityElementsHidden,
  importantForAccessibility,
  testID,
  ...props
}: IconProps) => {
  let SvgIcon = icons[name];
  let defaultSvgProps: SvgProps = {};

  // Icons declared as tuples can pass initial custom properties
  if (Array.isArray(SvgIcon)) {
    [SvgIcon, defaultSvgProps] = icons[name] as [FC<SvgProps>, SvgProps];
  }

  // The order of overriding props is: defaultSvgProps -> Icon props -> default values
  const iconProps = {
    ...defaultSvgProps,
    ...props,
    // Order of overriding prop we want to set a default value:
    // prop -> defaultSvgProp -> default value
    fill:
      theme.colors[color ?? 'secondary'] ??
      defaultSvgProps.color ??
      theme.colors.primary,
    width: props.size ?? defaultSvgProps.width ?? 24,
    height: props.size ?? defaultSvgProps.height ?? 24,
    accessibilityRole:
      accessibilityRole ?? defaultSvgProps.accessibilityRole ?? 'image',
    accessibilityElementsHidden:
      accessibilityElementsHidden ??
      defaultSvgProps.accessibilityElementsHidden ??
      true,
    importantForAccessibility:
      importantForAccessibility ??
      defaultSvgProps.importantForAccessibility ??
      'no',
    testID,
  };

  if (typeof SvgIcon === 'function') {
    return <SvgIcon {...iconProps} />;
  }

  throw new Error(`Icon '${name}' was not found.`);
};
