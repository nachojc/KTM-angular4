import {
  backgroundColorShorthand,
  border,
  createVariant,
  layout,
  opacity,
  position,
  spacingShorthand,
  visible,
} from '@shopify/restyle';
import {
  Pressable as RNPressable,
  PressableProps as RNPressableProps,
} from 'react-native';
import {
  BackgroundColorShorthandProps,
  BorderProps,
  LayoutProps,
  OpacityProps,
  PositionProps,
  SpacingShorthandProps,
  VariantProps,
  VisibleProps,
  createRestyleComponent,
} from '../../../themes/theme';

export type PressableProps = RNPressableProps &
  BackgroundColorShorthandProps &
  OpacityProps &
  VisibleProps &
  LayoutProps &
  SpacingShorthandProps &
  BorderProps &
  PositionProps &
  VariantProps<'shadowVariants', 'shadowVariant'>;

export const Pressable = createRestyleComponent<PressableProps>(
  [
    backgroundColorShorthand,
    opacity,
    visible,
    layout,
    spacingShorthand,
    border,
    // @ts-expect-error. It's a Shopify issue, we can add zIndices to the theme and fix it but it is useless
    position,
    createVariant({ themeKey: 'shadowVariants', property: 'shadowVariant' }),
  ],
  RNPressable
);

Pressable.displayName = 'Pressable';
