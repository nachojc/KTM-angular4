import { fireEvent, render, screen } from '../../../../../jest';
import { FloatingActionButton } from '../floating-action-button';

describe('FloatingActionButton', () => {
  it('should call onPress function when tapped', () => {
    const mockOnPress = jest.fn();
    render(<FloatingActionButton onPress={mockOnPress} label="Live chat" />);

    fireEvent.press(screen.getByText('Live chat'));

    expect(mockOnPress).toHaveBeenCalledTimes(1);
  });
});
