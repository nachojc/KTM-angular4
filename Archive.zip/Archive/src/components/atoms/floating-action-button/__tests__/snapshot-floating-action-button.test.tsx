import { render, screen } from '../../../../../jest';
import { FloatingActionButton } from '../floating-action-button';

describe('FloatingActionButton', () => {
  it.each(['left', 'right'] as const)(
    'should render floating action button with %s icon',
    (iconPosition) => {
      render(<FloatingActionButton iconPosition={iconPosition} />);

      expect(screen).toMatchSnapshot();
    }
  );

  it.each(['left', 'right', undefined] as const)(
    'should render floating action button with label and correct icon',
    (iconPosition) => {
      render(
        <FloatingActionButton label="Live chat" iconPosition={iconPosition} />
      );

      expect(screen).toMatchSnapshot();
    }
  );
});
