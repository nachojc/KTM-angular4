import { PositionProps } from '@shopify/restyle';
import { Theme } from 'themes/theme';
import { Icon } from '../icon';
import { Pressable, PressableProps } from '../pressable';
import { Text } from '../text';

export type FloatingActionButtonProps = {
  label?: string;
  iconPosition?: 'left' | 'right';
} & Pick<
  PressableProps,
  'onPress' | 'testID' | 'accessibilityHint' | 'accessibilityLabel'
> &
  PositionProps<Theme>;

export const FloatingActionButton = ({
  label,
  iconPosition,
  onPress,
  ...rest
}: FloatingActionButtonProps) => (
  <Pressable
    bg="primary"
    minWidth={56}
    minHeight={56}
    justifyContent="center"
    flexDirection="row"
    alignItems="center"
    borderRadius={999}
    p="sm"
    g="3xs"
    onPress={onPress}
    style={({ pressed }) => [{ opacity: pressed ? 0.75 : 1 }]}
    shadowVariant="md"
    accessibilityRole="button"
    {...rest}
  >
    {iconPosition === 'left' && <Icon color="secondary" name="chat-bubble" />}
    {!!label && (
      <Text fontFamily="SourceSansPro-Bold" color="secondary">
        {label}
      </Text>
    )}
    {iconPosition === 'right' && <Icon color="secondary" name="chat-bubble" />}
  </Pressable>
);
