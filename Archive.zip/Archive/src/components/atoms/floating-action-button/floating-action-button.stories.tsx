import { Meta, StoryObj } from '@storybook/react';
import {
  FloatingActionButton,
  FloatingActionButtonProps,
} from './floating-action-button';

/**
 *
 * Floating Action Button enables to put floating button over content of a screen.
 * Currently supports only Live chat label and icons
 * supports Restyle PositionProps for easy placement on a screen.
 */

const FloatingActionButtonMeta: Meta<FloatingActionButtonProps> = {
  title: 'Atoms/Floating Action Button',
  component: FloatingActionButton,
  tags: ['autodocs'],
  args: { label: 'Live chat', iconPosition: 'left' },
  parameters: { actions: { argTypesRegex: '^on.*' } },
  argTypes: {
    onPress: { action: 'pressed', type: 'function' },
    iconPosition: {
      options: ['left', 'right', undefined],
      control: { type: 'select' },
    },
  },
};

export default FloatingActionButtonMeta;

export const FloatingActionButtonWithLeftIcon: StoryObj<FloatingActionButtonProps> =
  { args: { ...FloatingActionButtonMeta.args } };

export const FloatingActionButtonWithRightIcon: StoryObj<FloatingActionButtonProps> =
  { args: { ...FloatingActionButtonMeta.args, iconPosition: 'right' } };

export const FloatingActionButtonWithoutLabel: StoryObj<FloatingActionButtonProps> =
  { args: { ...FloatingActionButtonMeta.args, label: undefined } };
