import { fireEvent, render, screen } from '../../../../../jest';
import { theme } from '../../../../themes/theme';
import { Link } from '../link';

describe('Link', () => {
  it('should call onPress function when tapped', () => {
    const mockOnPress = jest.fn();
    render(
      <Link variant="body" onPress={mockOnPress} testID="link">
        Press Me
      </Link>
    );

    const link = screen.getByText('Press Me');
    fireEvent.press(link);
    fireEvent.press(link);

    expect(mockOnPress).toHaveBeenCalledTimes(2);
  });

  it('renders correctly in disabled state', () => {
    render(
      <Link variant="body" disabled testID="link">
        Press Me
      </Link>
    );

    const link = screen.getByTestId('link');
    const linkText = screen.getByText('Press Me');

    expect(linkText).toHaveStyle({
      color: theme.colors.iconDark,
    });
    expect(link).toBeDisabled();
  });

  it('renders correctly', () => {
    render(<Link testID="link">Default Link</Link>);

    expect(screen.getByText('Default Link')).toBeVisible();
  });
});
