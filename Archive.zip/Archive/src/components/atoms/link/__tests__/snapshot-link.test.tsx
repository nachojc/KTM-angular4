import { render, screen } from '../../../../../jest';
import { Link } from '../link';

describe('Link', () => {
  it('Renders correctly', () => {
    render(<Link testID="link">Default Link</Link>).toJSON();
    expect(screen).toMatchSnapshot();
  });
});
