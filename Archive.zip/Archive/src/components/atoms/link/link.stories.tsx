import { Meta } from '@storybook/react';
import { fontFamily, theme } from '../../../themes/theme';
import { Text, TextProps } from '../text';
import { Link, LinkProps } from './link';

type StoryLinkArgs = LinkProps &
  Pick<TextProps, 'fontFamily'> & { text: string; disabled?: boolean };

const LinkMeta: Meta<StoryLinkArgs> = {
  title: 'Atoms/Link',
  component: Link,
  tags: ['autodocs'],
  args: { text: 'Link', disabled: false, variant: 'body' },
  argTypes: {
    onPress: { action: 'pressed', type: 'function' },
    variant: {
      options: Object.keys(theme.textVariants).filter(
        (key) => key !== 'default'
      ),
      control: { type: 'select' },
      description: 'Variant allows to apply predefined styles from the theme.',
      table: { defaultValue: { summary: 'body' } },
    },
    fontFamily: {
      options: Object.values(fontFamily),
      control: { type: 'select' },
      description:
        'Specifies the font family for the text. This property can also be used to change the font weight by selecting a font family that corresponds to different weight (e.g. SourceSansProBold will refer to fontWeight: 700.',
    },
  },
};

export default LinkMeta;

export const HeaderLink = (args: StoryLinkArgs) => (
  <Link onPress={args.onPress} disabled={args.disabled} variant={args.variant}>
    The quick brown fox jumps over...
  </Link>
);

export const LinkInText = (args: StoryLinkArgs) => (
  <Text variant={args.variant}>
    <Text>
      A paragraph of body copy text shows how inline links with icons will be
      displayed when they need to be displayed in this context. The icon always
      follows the corresponding link copy as this aids the user’s understanding:
      what they have read is then reinforced by the icon that follows on. For
      more information please bookmark this{' '}
    </Text>
    <Link
      onPress={args.onPress}
      disabled={args.disabled}
      variant={args.variant}
    >
      {args.text}
    </Link>
    <Text>
      {' '}
      it is assumed the ‘previous’ and ‘reply’ link with icon won’t need to be
      shown in this context, and so there shouldn’t be any instances where it
      might make more sense to place the icon before its corresponding copy.
    </Text>
  </Text>
);

export const LinkWithIcon = (args: StoryLinkArgs) => (
  <Text variant={args.variant}>
    A paragraph of body copy text shows how inline links with icons will be
    displayed when they need to be displayed in this context. The icon always{' '}
    <Link
      onPress={args.onPress}
      disabled={args.disabled}
      variant={args.variant}
      iconName="download"
    >
      {args.text}
    </Link>{' '}
    it is assumed the ‘previous’ and ‘reply’ link with icon won’t need to be
  </Text>
);
