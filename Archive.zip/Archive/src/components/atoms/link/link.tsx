import { useState } from 'react';
import { Theme } from '../../../themes/theme';
import { Icon, IconName } from '../icon/icon';
import { Text, TextProps } from '../text/text';

export type LinkProps = Pick<
  TextProps,
  'children' | 'onPress' | 'disabled' | 'testID'
> & { variant?: keyof Theme['textVariants']; iconName?: IconName };

export const Link = ({
  children,
  variant = 'body',
  iconName,
  ...rest
}: LinkProps) => {
  const [pressed, setPressed] = useState(false);

  const color = rest.disabled ? 'iconDark' : 'tertiary';

  return (
    <>
      <Text
        onPressIn={() => setPressed(true)}
        onPressOut={() => setPressed(false)}
        suppressHighlighting
        accessibilityLabel="link"
        accessibilityRole="link"
        fontFamily="SourceSansPro-Bold"
        color={color}
        textDecorationLine={pressed ? 'none' : 'underline'}
        variant={variant}
        {...rest}
      >
        {children}{' '}
      </Text>
      {!!iconName && <Icon size="16" name={iconName} color={color} />}
    </>
  );
};
