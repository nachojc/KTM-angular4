export const getRandomWords = (
  length: number,
  currentText: string[] = []
): string => {
  if (length === 0) {
    return currentText.join(' ') + '.';
  } else {
    currentText.push(getWord());
    return getRandomWords(length - 1, currentText);
  }
};

const getWord = (): string => {
  const words =
    'lorem ipsum dolor sit amet consectetur adipiscing elit integer non imperdiet nisi';
  const wordsArr = words.split(' ');
  const wordIndex = Math.floor(Math.random() * 10);

  return wordsArr[wordIndex] ?? 'lorem';
};
