import { ReactNode } from 'react';
import { theme } from '../themes/theme';
import { ThemeProvider } from '@shopify/restyle';

type IonMobileProviderProps = {
  children: ReactNode;
};

export const IonMobileProvider = ({ children }: IonMobileProviderProps) => (
  <ThemeProvider theme={theme}>{children}</ThemeProvider>
);
