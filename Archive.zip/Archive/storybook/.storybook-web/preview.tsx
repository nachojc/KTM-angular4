import { Preview } from '@storybook/react';
import React from 'react';
import { IonMobileProvider } from '../../src';
import { palette } from '../../src/themes/palette';
import { FontLoader } from '../assets/fonts/font-loader';
import './fonts.css';

const preview: Preview = {
  decorators: [
    (Story) => {
      return (
        <FontLoader>
          <IonMobileProvider>
            {/* {Story() syntax helps to fix error "Storybook preview hooks..." during first story render on web. 
            Explanation is here: [github](https://github.com/storybookjs/storybook/issues/22132#issuecomment-1512657923 )} */}
            {Story()}
          </IonMobileProvider>
        </FontLoader>
      );
    },
  ],
  parameters: {
    actions: { argTypesRegex: '^on[A-Z].*' },
    backgrounds: {
      default: 'transparent',
      values: Object.keys(palette).map((key) => ({
        name: key,
        value: palette[key],
      })),
    },
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/i,
      },
    },
  },
};

export default preview;
