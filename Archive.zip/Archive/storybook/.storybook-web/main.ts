import { StorybookConfig } from '@storybook/react-webpack5';
import { RuleSetRule } from 'webpack';

const path = require('path');

const root = path.resolve(__dirname, '../..');

const node_modules = path.join(__dirname, '../node_modules');

const main: StorybookConfig = {
  stories: [
    '../../src/components/**/*.mdx',
    '../../src/components/**/*.stories.?(ts|tsx|js|jsx)',
    '../../src/themes/**/*.mdx'
  ],
  addons: [
    '@storybook/addon-links',
    '@storybook/addon-essentials',
    '@storybook/addon-react-native-web',
    '@storybook/addon-webpack5-compiler-babel',
    '@storybook/addon-docs',
    '@storybook/addon-actions'
  ],
  framework: {
    name: '@storybook/react-webpack5',
    options: {},
  },
  docs: {
    autodocs: 'tag',
  },
  webpackFinal: async (config) => {
    if (config.resolve)
      config.resolve.alias = {
        ...config.resolve.alias,
        'react-native-web': path.join(node_modules, 'react-native-web'),
        'expo-modules-core': path.resolve(node_modules, 'expo-modules-core'),
        'expo-asset': path.resolve(node_modules, 'expo-asset'),
      };
      const rules = config?.module?.rules as RuleSetRule[];
      const imageRule = rules.find(
        (rule) => rule?.test instanceof RegExp && rule.test.test('.svg'),
      );
      if (imageRule) {
        imageRule.exclude = /\.svg$/;
      }
      rules.push({
        test: /\.svg$/,
        use: ['@svgr/webpack'],
      });
    return config;
  },
};

export default main;
