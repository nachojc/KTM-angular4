import { withBackgrounds } from '@storybook/addon-ondevice-backgrounds';
import type { Preview } from '@storybook/react';
import * as React from 'react';
import { IonMobileProvider } from '../../src';
import { palette } from '../../src/themes/palette';
import { FontLoader } from '../assets/fonts/font-loader';

const preview: Preview = {
  decorators: [
    (Story) => {
      return (
        <FontLoader>
          <IonMobileProvider>
            {/* {Story() syntax helps to fix error "Storybook preview hooks..." during first story render on web. 
            Explanation is here: [github](https://github.com/storybookjs/storybook/issues/22132#issuecomment-1512657923 )} */}
            {Story ()}
          </IonMobileProvider>
        </FontLoader>
      );
    },
    withBackgrounds,
  ],
  parameters: {
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/,
      },
    },
    backgrounds: {
      default: 'Neutral100',
      values: Object.keys(palette).map((key) => ({
        name: key,
        value: palette[key],
      })),
    },
  },
};

export default preview;
