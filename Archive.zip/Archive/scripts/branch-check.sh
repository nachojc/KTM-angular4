
local_branch="$(git rev-parse --abbrev-ref HEAD)"
valid_branch_regex="^(bugfix|feature|maintenance|release|spike|task)\/[a-zA-Z0-9\.\-]+(\/[a-zA-Z0-9\.\-]+)*$"

if [[ ! $local_branch =~ $valid_branch_regex ]]
then
    echo "\nYour branch $local_branch has an invalid name, it should follow: $valid_branch_regex. Please rename your branch with the following and try again."
    echo "\n  git branch -m old-branch-name new-branch-name"
    echo "  git push origin --delete old-name (may fail due to permissions)"
    echo "  git push origin -u new-name"

    echo "\n  For example feature/MANGA-4545-human-readable-bit \n"
    exit 1
fi
