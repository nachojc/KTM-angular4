const fs = require('fs');

function camelize(text) {
  const a = text
    .toLowerCase()
    .replace(/[-_\s.]+(.)?/g, (_, c) => (c ? c.toUpperCase() : ''));
  return a.substring(0, 1).toLowerCase() + a.substring(1);
}

function getFilesFromPath(dirPath, extension) {
  let files = fs.readdirSync(dirPath);
  return files.filter((file) =>
    file.match(new RegExp(`.*\.(${extension})`, 'ig'))
  );
}

const files = getFilesFromPath('src/themes/icons', '.svg');
files
  .map(
    (name) => `import ${camelize(name.replace('.svg', ''))} from './${name}'`
  )
  .forEach((i) => console.log(i));
console.log(
  files
    .map(
      (f) =>
        `'${f.replace('_', '-').replace('.svg', '')}': ${camelize(
          f.replace('.svg', '')
        )}`
    )
    .join(', ')
);
