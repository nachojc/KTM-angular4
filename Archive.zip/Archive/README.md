# react-native-ion-mobile

UI Library

# Develop

## Getting Started

1. Clone the project
2. Run yarn to install dependecies

```sh
yarn
```

3. Run Storybook
4. Publish and release

## Storybook

Storybook is set ups within the example folder as a wrokspace of the package. and it will pick up any story that is created within the `src/components` folder of the rootDirectory.

After you write a new story or modify an existing story you need to run

```sh
yarn storybook generate
```

or restart metro bundler (by default it will generate new stories)

```sh
yarn start
```

Before running Storybook on a physical device or emulator you need to ensure expo-go it's installed (usually this step is not necessary as it's download automatically but Aviva has this urls blocked for security reasons). However, if you open `OneDrive/Macbook install/expo-client` you will see 2 files one APK for android and .app for ios. Just select the one you need and drag and drop into the emulator.

Run storybook on ios

```sh
yarn ios
```

Run storybook on android

```sh
yarn android
```

Run storybook on web

```sh
yarn web
```

## How to publish and release a new version

**_NOTE:_** Currently the it's using Artifactory as registry, but need to be moved to NPM as pipelines do not use Artifactory.

1. Bump version of the package on package.json
2. Run the script `yarn prepare`
3. Set up the your environment to publish

```sh
npm config set registry https://binaries.avivagroup.com/artifactory/api/npm/manga-npm-local/
```

4. Login to artifactory

```sh
npm login
```

5. Publish the package

```sh
npm publish
```

## To unpublish a specific version

```sh
npm unpublish react-native-ion-mobile@<version_number>
```

# Consuming the package

## Installation

```sh
yarn add react-native-ion-mobile
```

## Installation as @aviva/ion-mobile

```sh
yarn add @aviva/ion-mobile@npm:react-native-ion-mobile
```

## Usage

```js
import { Button } from 'react-native-ion-mobile';
```
