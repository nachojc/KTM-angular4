import '@testing-library/jest-native';

import mockSafeAreaContext from 'react-native-safe-area-context/jest/mock';
import './jest-extensions';

jest.mock('react-native-reanimated', () => {
  const Reanimated = require('react-native-reanimated/mock');
  Reanimated.default.call = () => ({});
  Reanimated.useHandler = jest.fn();
  return Reanimated;
});

jest.mock('react-native-safe-area-context', () => mockSafeAreaContext);
