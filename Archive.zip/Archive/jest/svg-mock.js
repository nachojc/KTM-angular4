import Svg from 'react-native-svg';

const SvgMock = (props) => <Svg {...props} />;

export default SvgMock;
