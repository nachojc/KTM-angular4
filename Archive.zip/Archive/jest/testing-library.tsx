import { ReactElement, ReactNode } from 'react';

import '@testing-library/jest-native/';
import { render, RenderOptions, screen } from '@testing-library/react-native';
import { IonMobileProvider } from '../src/provider';

export const MockProviders = ({ children }: { children: ReactNode }) => {
  return <IonMobileProvider>{children}</IonMobileProvider>;
};
const customRender = (component: ReactElement, options?: RenderOptions) =>
  render(component, {
    wrapper: MockProviders, // TODO: we may want to make this optional to avoid long test times
    ...options,
  });
export * from '@testing-library/react-native';

export { customRender as render, screen };
