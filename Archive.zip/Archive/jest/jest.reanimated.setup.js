import { setUpTests } from 'react-native-reanimated/lib/module/reanimated2/jestUtils';

setUpTests();
