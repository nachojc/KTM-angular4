import { expect } from '@jest/globals';
import {
  toBeDisabled,
  toBeEnabled,
} from '@testing-library/jest-native/dist/to-be-disabled';
import { MatcherFunction } from 'expect';

// A custom matcher to allow conditional tests like `expect(myComponent).toBeEnabledWithCondition(buttonState === 'enabled')`
export const toBeEnabledWithCondition: MatcherFunction<[enabled: unknown]> =
  function (actual, enabled) {
    return enabled
      ? toBeEnabled.call(this, actual)
      : toBeDisabled.call(this, actual);
  };

expect.extend({
  toBeEnabledWithCondition,
});

expect.extend({
  toContainUniqueItems(received) {
    const items = [...(received || [])];
    items.sort();
    for (let i = 0; i < items.length - 1; i++) {
      if (items[i] === items[i + 1]) {
        return {
          pass: false,
          message: () => `Item ${items[i]} is repeated.`,
        };
      }
    }

    return {
      pass: true,
      message: () => `All items are unique`,
    };
  },
});

type CustomMatchers<R> = {
  toBeEnabledWithCondition: (enabled: boolean) => R;
  toContainUniqueItems: () => R;
  toHaveAnimatedStyle: (
    style: Record<string, unknown>[] | Record<string, unknown>
  ) => R;
};

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace jest {
    //@ts-ignore
    type Matchers<R, T = NonNullable<unknown>> = CustomMatchers<R>;
  }
}

// declare module '@jest/expect' {
//   //@ts-ignore
//   type Matchers<R extends void | Promise<void>> = CustomMatchers<R>;
// }
